var $products = $('#products'),
    $productscategory = $('#productscategory'),
    $options = $productscategory.find('option');

$products.on('change', function() {
    $productscategory.html($options.filter('[value="' + this.value + '"]'));
}).trigger('change');